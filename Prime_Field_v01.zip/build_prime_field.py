#!/usr/bin/env python3
"""Deterministic, standalone prime-field chart example.

Not an authorization mechanism, signature, acoustics simulation or implementation
of constitutional sovereignty. Rendered geometry is a typed observational chart.
Python standard library only. Source order and asymmetry are preserved.
"""
from __future__ import annotations

import argparse
import csv
from itertools import count
import hashlib
import json
import math
from pathlib import Path
import xml.etree.ElementTree as ET
from xml.sax.saxutils import escape

N_DIGITS = 529
N_STATIONS = 7
NOMINAL_CYCLE_DEGREES = 367
SOURCE_ROTATION_DEGREES = -23  # Cartesian positive is counterclockwise
DIGIT_COLOR = {2: '#F47B72', 3: '#71CCE8', 5: '#A3D9A4', 7: '#C7A5EB'}


def prime(n: int) -> bool:
    if n < 2:
        return False
    for d in range(2, math.isqrt(n) + 1):
        if n % d == 0:
            return False
    return True


def concatenated_prime_digits(length: int = N_DIGITS) -> str:
    chunks = []
    total = 0
    for n in count(2):
        if prime(n):
            chunk = str(n)
            chunks.append(chunk)
            total += len(chunk)
            if total >= length:
                return ''.join(chunks)[:length]
    raise AssertionError('unreachable')


def square_spiral(length: int = N_DIGITS) -> dict[int, tuple[int, int]]:
    # 1 -> (0,0); right 1, up 1, left 2, down 2, ...
    positions = {1: (0, 0)}
    x = y = 0
    index = 2
    run_length = 1
    directions = [(1, 0), (0, 1), (-1, 0), (0, -1)]
    turn = 0
    while index <= length:
        for _ in range(2):
            dx, dy = directions[turn % 4]
            for _ in range(run_length):
                if index > length:
                    break
                x, y = x + dx, y + dy
                positions[index] = (x, y)
                index += 1
            turn += 1
        run_length += 1
    return positions


def rotate_cartesian(x: float, y: float, degrees: float) -> tuple[float, float]:
    t = math.radians(degrees)
    c, s = math.cos(t), math.sin(t)
    return c*x - s*y, s*x + c*y


def selected_positions() -> list[dict]:
    digits = concatenated_prime_digits()
    pos = square_spiral()
    rows = []
    for idx, char in enumerate(digits, 1):
        digit = int(char)
        if prime(idx) and digit in DIGIT_COLOR:
            x, y = pos[idx]
            rx, ry = rotate_cartesian(x, y, SOURCE_ROTATION_DEGREES)
            rows.append(dict(source_digit_position=idx, prime_digit=digit, x_grid=x, y_grid=y,
                             x_rotated=rx, y_rotated=ry, svg_x=600+34*rx, svg_y=600-34*ry))
    return rows


def rotor_points() -> list[dict]:
    """One declared 367-degree nominal sweep projected on a physical 360-degree chart."""
    return [dict(station=j + 1, sweep_degrees=j*NOMINAL_CYCLE_DEGREES/N_STATIONS,
                 display_degrees=(j*NOMINAL_CYCLE_DEGREES/N_STATIONS)%360)
            for j in range(N_STATIONS)]


def source_svg_check(source: Path, rows: list[dict]) -> dict:
    ns = {'s': 'http://www.w3.org/2000/svg'}
    root = ET.parse(source).getroot()
    group = next(g for g in root.findall('.//s:g', ns) if g.attrib.get('id') == 'spiral-prime-points')
    pts = list(group)
    if len(rows) != len(pts):
        raise AssertionError(f'Source point count {len(pts)} != regenerated {len(rows)}')
    worst_err = 0
    for row, circle in zip(rows, pts):
        a = circle.attrib
        expected = dict(source_digit_position=int(a['data-index']), prime_digit=int(a['data-digit']),
                        x_grid=int(a['data-source-x']), y_grid=int(a['data-source-y']))
        for key, value in expected.items():
            if row[key] != value:
                raise AssertionError(f'Source mismatch at {key}: {row[key]} != {value}')
        err = max(abs(row['svg_x']-float(a['cx'])), abs(row['svg_y']-float(a['cy'])))
        worst_err = max(err, worst_err)
        if err > 1.1e-6:
            raise AssertionError(f'Source visual coordinate mismatch: {err:.8f}')
    return dict(status='PASSED', points=len(rows), max_coordinate_absolute_error=worst_err,
                source_svg_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
                coordinate_tolerance=1.1e-6)


def validation() -> dict:
    spiral = square_spiral()
    selected = selected_positions()
    assert len(spiral) == 529
    assert len(set(spiral.values())) == 529
    assert (min(x for x,y in spiral.values()),max(x for x,y in spiral.values())) == (-11,11)
    assert (min(y for x,y in spiral.values()),max(y for x,y in spiral.values())) == (-11,11)
    assert [spiral[k] for k in range(1,6)] == [(0,0),(1,0),(1,1),(0,1),(-1,1)]
    assert len(selected) == 43
    assert selected[0]['source_digit_position'] == 2
    assert all(prime(r['source_digit_position']) and r['prime_digit'] in DIGIT_COLOR for r in selected)
    assert len({r['source_digit_position'] for r in selected}) == len(selected)
    assert prime(367) and prime(127) and prime(1109) and prime(853)
    assert 437 == 19*23 and not prime(437)
    # Relative angle exactly B*n/84 (degrees); projection makes residuals nonzero.
    assert 367*84//84 % 360 == 7
    assert 367*924//84 % 360 == 77
    assert (360*84)//math.gcd(367,360*84) == 30240
    hp = (360*231)//math.gcd(367,360*231)
    qp = (360*132)//math.gcd(367,360*132)
    assert math.lcm(hp,qp) == 332640
    assert len(rotor_points()) == 7
    assert abs((360 - rotor_points()[-1]['display_degrees']) - (367/7 - 7)) < 1e-9
    return dict(status='PASSED', spiral_positions=529, selected_points=43,
                relative_residual_84_steps_degrees=7,relative_residual_924_steps_degrees=77,
                relative_period_steps=30240, combined_orientation_period_steps=332640,
                source_crosscheck='optional: supply archival source SVG')


def write_csv(out: Path, rows: list[dict], rotor: list[dict]) -> None:
    with (out/'prime_witness_43_points.csv').open('w',newline='',encoding='utf-8') as f:
        writer = csv.DictWriter(f,fieldnames=list(rows[0]))
        writer.writeheader();writer.writerows(rows)
    with (out/'seven_station_367_nominal.csv').open('w',newline='',encoding='utf-8') as f:
        writer = csv.DictWriter(f,fieldnames=list(rotor[0]))
        writer.writeheader();writer.writerows(rotor)


def write_svg(out: Path, rows: list[dict], rotor: list[dict]) -> None:
    # A fresh reference composition: left 43-hit open path, right declared seven sites.
    # No handwritten marks, identifying signatures, implied authorization or hidden markers.
    s = ['<svg xmlns="http://www.w3.org/2000/svg" width="1600" height="920" viewBox="0 0 1600 920" role="img" aria-labelledby="title desc">',
         '<title id="title">Prime Field Witness — 43 source hits and seven-site 367-degree nominal rotor</title>',
         '<desc id="desc">Two independent data-derived panels, an open 43-hit square spiral selected from concatenated primes and an illustrative seven-station 367-degree sweep. No declared coupling between panels or physical acoustics.</desc>',
         '<defs><linearGradient id="bg" x2="1" y2="1"><stop stop-color="#070b19"/><stop offset="1" stop-color="#171036"/></linearGradient></defs>',
         '<rect width="1600" height="920" fill="url(#bg)"/>',
         '<rect x="35" y="86" width="820" height="760" rx="24" fill="#0e1830" stroke="#4a436b"/>',
         '<rect x="877" y="86" width="688" height="760" rx="24" fill="#0e1830" stroke="#4a436b"/>',
         '<text x="45" y="53" font-size="30" font-family="sans-serif" fill="#f4ddb4">OMNIBUS · PRIME-FIELD WITNESS / proposed chart</text>',
         '<text x="70" y="130" font-size="21" font-family="sans-serif" fill="#e9d4a5">43 prime-digit hits / open source-order path</text>',
         '<text x="900" y="130" font-size="21" font-family="sans-serif" fill="#e9d4a5">Seven stations / B = 367° projected on 360°</text>']
    # Reposition original source-rotated coordinates into left chart, with 0.85 scale.
    cx=445; cy=474; scale=22
    svgpts=[(cx+scale*r['x_rotated'], cy-scale*r['y_rotated']) for r in rows]
    s.append('<g id="prime-source-order" fill="none" stroke="#dcc293" stroke-width="2.2">')
    s.append('<polyline points="'+' '.join(f'{x:.6f},{y:.6f}' for x,y in svgpts)+'"/>')
    s.append('</g>')
    for (x,y),r in zip(svgpts, rows):
        s.append(f'<circle data-index="{r["source_digit_position"]}" data-digit="{r["prime_digit"]}" cx="{x:.6f}" cy="{y:.6f}" r="4.9" fill="{DIGIT_COLOR[r["prime_digit"]]}"/>')
    # Reference origin is intentionally separate and hollow.
    s.append(f'<circle cx="{cx}" cy="{cy}" r="14" fill="none" stroke="#e9d4a5" stroke-width="2"/>')
    s.append('<text x="70" y="786" fill="#aebbd2" font-size="17" font-family="sans-serif">Open polyline, 43 points; no forced closure or smoothing.</text>')
    s.append('<text x="70" y="816" fill="#aebbd2" font-size="16" font-family="sans-serif">Grid: right/up square spiral · Cartesian rotation -23 deg · y-up</text>')
    # Seven-site 367-degree nominated sweep on ordinary physical-degree display.
    cx=1218;cy=464;r=225
    coords=[]
    for row in rotor:
        rad=math.radians(row['display_degrees']-90)
        coords.append((cx+r*math.cos(rad),cy+r*math.sin(rad)))
    s.append('<g fill="none" stroke="#b89dd8" stroke-width="1.8" opacity="0.5">')
    for rad in [100,160,225]:
        s.append(f'<circle cx="{cx}" cy="{cy}" r="{rad}" stroke-dasharray="3 9"/>')
    s.append('</g>')
    s.append('<polyline points="'+' '.join(f'{x:.6f},{y:.6f}' for x,y in coords)+'" stroke="#f4be80" stroke-width="2.4" fill="none"/>')
    x,y=coords[-1];x2,y2=coords[0]
    s.append(f'<path d="M {x:.6f},{y:.6f} L {x2:.6f},{y2:.6f}" stroke="#d05e9d" stroke-width="2" stroke-dasharray="7 8" fill="none"/>')
    for row,(x,y) in zip(rotor,coords):
        s.append(f'<circle cx="{x:.6f}" cy="{y:.6f}" r="11" fill="#74dddc" stroke="#071b2d" stroke-width="2"/>')
        s.append(f'<text x="{x+16:.6f}" y="{y+4:.6f}" fill="#f6e8d2" font-size="17" font-family="sans-serif">P{row["station"]}</text>')
    s.append(f'<circle cx="{cx}" cy="{cy}" r="7" fill="none" stroke="#e9d4a5" stroke-width="2"/>')
    s.append('<text x="900" y="786" fill="#aebbd2" font-size="17" font-family="sans-serif">Dashed final edge = declared seam, 7° gap difference.</text>')
    s.append('<text x="900" y="816" fill="#aebbd2" font-size="16" font-family="sans-serif">127 = prime anchor · 437 = 19 × 23, composite; 437 Hz illustrative only</text>')
    s.append('<text x="38" y="889" fill="#c7cbd8" font-size="15" font-family="sans-serif">C and K chart witness only · field ℒ does not become a mediator · not measured acoustics · no personal signature</text>')
    s.append('</svg>')
    (out/'prime_field_43_plus_7_atlas.svg').write_text('\n'.join(s)+'\n',encoding='utf-8')


def main() -> None:
    ap=argparse.ArgumentParser()
    ap.add_argument('--out',default='.',help='output directory')
    ap.add_argument('--check-source-svg',help='optional previous source SVG for point cross-check')
    ap.add_argument('--verify-only',action='store_true')
    args=ap.parse_args()
    out=Path(args.out)
    v=validation()
    rows=selected_positions()
    if args.check_source_svg:
        v['prior_svg_crosscheck']=source_svg_check(Path(args.check_source_svg),rows)
    if not args.verify_only:
        out.mkdir(parents=True,exist_ok=True)
        write_csv(out,rows,rotor_points())
        write_svg(out,rows,rotor_points())
        (out/'validation_results.json').write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(v,indent=2))

if __name__=='__main__':
    main()
