@echo off
cd /d "%~dp0"
py ship.py --config protocol.json --out output
if errorlevel 1 (
  echo RUN FAILED: ensure you have Python and the dependencies in requirements.txt
  exit /b 1
)
py test_ship.py
if errorlevel 1 (
  echo TESTS FAILED: output receipts were not refreshed by plotting
  exit /b 1
)
py plot_results.py
if errorlevel 1 (
  echo PLOTTING FAILED: see the error above
  exit /b 1
)
pause
