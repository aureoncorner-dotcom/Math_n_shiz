#!/usr/bin/env python3
"""C7-CTA-GQG-PILOT-001: reproducible exploratory orbital geometry.

No historical labels, no claim of a physical coupling or a cosmic bifurcation.
This script is a new implementation, not a reproduction of the original CTA/PRP executable.

Run: python ship.py --config protocol.json --out output
Requires pyswisseph, numpy and scipy; plot_results.py requires matplotlib.
"""
from __future__ import annotations
import argparse, csv, hashlib, itertools, json, math, platform
from collections import Counter
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
import numpy as np
import scipy
import swisseph as swe

BODY_IDS = {
    "Mercury": swe.MERCURY, "Venus": swe.VENUS, "Earth": swe.EARTH,
    "Mars": swe.MARS, "Jupiter": swe.JUPITER, "Saturn": swe.SATURN,
    "Uranus": swe.URANUS, "Neptune": swe.NEPTUNE, "Pluto": swe.PLUTO,
}
IDEAL = 360.0 / 7.0
FLAGS = swe.FLG_MOSEPH | swe.FLG_J2000 | swe.FLG_TRUEPOS


def jd_date(x: date) -> float:
    return swe.julday(x.year, x.month, x.day, 0.0)


def jd_utc(jd: float) -> str:
    y, m, d, hour = swe.revjul(float(jd))
    dt = datetime(y, m, d, tzinfo=timezone.utc) + timedelta(hours=hour)
    return dt.isoformat(timespec="seconds").replace("+00:00", "Z")


def coords(jd: float, bodies: list[str], frame: str) -> dict[str, tuple[float, float]]:
    if frame not in ("hel", "geo", "eq"):
        raise ValueError("unknown frame")
    fl = FLAGS | (swe.FLG_HELCTR if frame == "hel" else 0) | (swe.FLG_EQUATORIAL if frame == "eq" else 0)
    return {name: tuple(swe.calc_ut(float(jd), BODY_IDS[name], fl)[0][:2]) for name in bodies}


def score(names: tuple[str, ...] | list[str], longitudes: dict[str, float]):
    ordered = sorted(names, key=lambda p: longitudes[p] % 360)
    a = np.array([longitudes[p] % 360 for p in ordered], dtype=float)
    family_errors = []
    family_rms = []
    for k in (1, 2, 3):
        de = (np.roll(a, -k) - a) % 360 - k * IDEAL
        family_errors.append([float(z) for z in de])
        family_rms.append(float(np.sqrt(np.mean(de * de))))
    gaps = ((np.roll(a, -1) - a) % 360).tolist()
    return {
        "members": list(names), "order": ordered,
        "gaps": [float(z) for z in gaps],
        "families_rms_deg": family_rms,
        "errors_deg": family_errors,
        "R1": float(abs(np.mean(np.exp(1j * np.deg2rad(a))))),
        "R7": float(abs(np.mean(np.exp(7j * np.deg2rad(a))))),
    }


def best7(all_names: list[str], lon: dict[str, float]):
    # Vectorized exhaustive choose-seven selection; only compute extended profile for winner.
    subsets = tuple(itertools.combinations(range(len(all_names)), 7))
    ang = np.array([lon[name] % 360 for name in all_names], dtype=float)
    slots = np.asarray(subsets, dtype=int)
    a = np.sort(ang[slots], axis=1)
    gap = (np.roll(a, -1, axis=1) - a) % 360
    f1 = np.sqrt(np.mean((gap - IDEAL)**2, axis=1))
    i = int(np.argmin(f1))
    return score([all_names[j] for j in subsets[i]], lon)


def great_circle_deg(coords_map: dict[str, tuple[float, float]], a: str, b: str) -> float:
    lo1, la1 = map(math.radians, coords_map[a]); lo2, la2 = map(math.radians, coords_map[b])
    v1 = (math.cos(la1)*math.cos(lo1), math.cos(la1)*math.sin(lo1), math.sin(la1))
    v2 = (math.cos(la2)*math.cos(lo2), math.cos(la2)*math.sin(lo2), math.sin(la2))
    d = math.sqrt(sum((u-v)**2 for u,v in zip(v1,v2)))
    s = min(1.0, 0.5*d)
    return math.degrees(2*math.asin(s))


def run(cfg, dest: Path):
    from scipy.optimize import brentq

    dest.mkdir(parents=True, exist_ok=True)
    start = date.fromisoformat(cfg["interval_start_utc_inclusive"][:10])
    end = date.fromisoformat(cfg["interval_end_utc_exclusive"][:10])
    dates = [start + timedelta(days=i) for i in range((end-start).days)]
    common = cfg["bodies_common"]
    nine = cfg["bodies_heliocentric_plus_earth"]
    rows = []
    daily = []
    saturn_diff = []
    max_shifts = {"hel8": 0.0, "geo8": 0.0}
    max_3d_rot = 0.0
    selection_swaps = {"hel8": 0, "geo8": 0, "equatorial8": 0, "hel9": 0}
    previous_members = {}
    pairwise_projection = []
    for dt in dates:
        jd = jd_date(dt)
        hel = coords(jd, nine, "hel")
        geo = coords(jd, common, "geo")
        eq = coords(jd, common, "eq")
        lon_h = {x: hel[x][0] for x in common}
        lon_g = {x: geo[x][0] for x in common}
        lon_e = {x: eq[x][0] for x in common}
        selected = {
            "hel8": best7(common, lon_h),
            "geo8": best7(common, lon_g),
            "equatorial8": best7(common, lon_e),
            "hel9": best7(nine, {x: hel[x][0] for x in nine}),
        }
        # The same H8-selected seven labels evaluated in the geocentric frame
        matched_g = score(selected["hel8"]["members"], lon_g)
        # A sidereal-style uniform rotation CANNOT change any pairwise gap.
        for lane, lon in (("hel8", lon_h), ("geo8", lon_g)):
            rotated = {k: (v - cfg["ephemeris"]["sidereal_shift_degrees"]) % 360 for k,v in lon.items()}
            s_shift = score(selected[lane]["members"], rotated)
            max_shifts[lane] = max(max_shifts[lane],abs(s_shift["families_rms_deg"][0]-selected[lane]["families_rms_deg"][0]))
        # Any true 3-D angular separation is invariant under a change of coordinate axes.
        for a,b in itertools.combinations(common,2):
            dd = abs(great_circle_deg(geo,a,b)-great_circle_deg(eq,a,b))
            max_3d_rot = max(max_3d_rot, dd)
        for lane, val in selected.items():
            member_key = tuple(sorted(val["members"]))
            if lane in previous_members and member_key != previous_members[lane]:
                selection_swaps[lane] += 1
            previous_members[lane] = member_key
            F = val["families_rms_deg"]
            rows.append({"date_utc":dt.isoformat(),"frame":lane,
                         "F1_deg":F[0],"F2_deg":F[1],"F3_deg":F[2],
                         "R1":val["R1"],"R7":val["R7"],
                         "members":"|".join(sorted(val["members"])),
                         "ordered_bodies":"|".join(val["order"])})
        daily.append({"date":dt.isoformat(),"jd":jd,"selected":selected,
                      "matched_geocentric_H8":matched_g})
        saturn_diff.append(((hel["Earth"][0] - hel["Saturn"][0] + 180) % 360) - 180)
    with (dest/"daily_scores.csv").open("w",newline="",encoding="utf8") as fp:
        writer=csv.DictWriter(fp,fieldnames=list(rows[0].keys()))
        writer.writeheader();writer.writerows(rows)

    # Parameters and the declared rule live in protocol.json; selected minima are non-inferential.
    minima=cfg["local_minima_selection"]
    rank=[]
    for frame in minima["lanes"]:
        sub=[r for r in rows if r["frame"]==frame]
        vals=np.array([float(r[minima["statistic"]]) for r in sub])
        ix=[i for i in range(1,len(vals)-1) if vals[i]<=vals[i-1] and vals[i]<vals[i+1]]
        ix=sorted(ix,key=lambda k:vals[k])
        picked=[]
        for i in ix:
            if all(abs(i-j)>=minima["minimum_separation_days"] for j in picked):picked.append(i)
            if len(picked)>=minima["top_per_lane"]:break
        rank.extend([dict(sub[i]) for i in picked])
    # Compute Earth-Saturn heliocentric conjunctions, defined by wrapped angle = 0.
    # The crossing of +/-180 is an opposition, not a conjunction.
    conjunctions=[]
    for i in range(len(daily)-1):
        a,b=saturn_diff[i:i+2]
        if a<=0<b or b<=0<a:
            if abs(a-b)>180:continue
            left,right=daily[i]["jd"],daily[i+1]["jd"]
            def delta(jd):
                q=coords(jd,["Earth","Saturn"],"hel")
                return ((q["Earth"][0]-q["Saturn"][0]+180)%360)-180
            jd=brentq(delta,left,right,xtol=1e-9)
            conjunctions.append(jd)
    # Compare fixed-length *event-anchored prediction dials* to actual astronomical conjunctions.
    # This is not the equinox/sunrise-anchored canonical Metatronic calendar.
    dial=[]
    if conjunctions:
        for n,jd in enumerate(conjunctions):
            row={"n":n,"actual_utc":jd_utc(jd),"since_previous_days":None if n==0 else jd-conjunctions[n-1]}
            for p in cfg["calendar"]["dial_periods_days"]:
                predicted=conjunctions[0]+n*p
                row[f"nominal_{p}_utc"]=jd_utc(predicted)
                row[f"actual_minus_{p}_days"]=jd-predicted
            dial.append(row)
        with (dest/"saturn_dials.csv").open("w",newline="",encoding="utf8") as fp:
            w=csv.DictWriter(fp,fieldnames=list(dial[0].keys()));w.writeheader();w.writerows(dial)
    # Exact finite graph check.
    all_edges={frozenset((i,j)) for i,j in itertools.combinations(range(7),2)}
    families=[{frozenset((i,(i+k)%7)) for i in range(7)} for k in (1,2,3)]
    assert all(len(f)==7 for f in families) and set.union(*families)==all_edges
    assert sum(len(f) for f in families)==21
    # Witness-collision check: 7 equally spaced vs 7 conjoined.
    regular={str(k):k*IDEAL for k in range(7)}
    together={str(k):100.0 for k in range(7)}
    coll_reg=score(list(regular), regular)
    coll_con=score(list(together), together)
    assert abs(coll_reg["R7"]-1)<1e-12 and abs(coll_con["R7"]-1)<1e-12
    assert coll_reg["R1"]<1e-12 and abs(coll_con["R1"]-1)<1e-12
    assert max(max_shifts.values())<1e-10
    assert max_3d_rot < 1e-5, f"3-D rotation invariant failure {max_3d_rot}"

    # Locate the 2029 snapshot rather than importing earlier unverified figures.
    snap=next((d for d in daily if d["date"]=="2029-01-07"),None)
    safe_snap = None
    if snap:
        safe_snap={"date_utc":snap["date"],"lanes":{
            frame: {"F1_F2_F3_deg":val["families_rms_deg"],"members":val["members"],"angular_order":val["order"],"R1":val["R1"],"R7":val["R7"]}
            for frame,val in snap["selected"].items()},
          "same_heliocentric_seven_in_geocentric":{"members":snap["selected"]["hel8"]["members"],"F1_F2_F3_deg":snap["matched_geocentric_H8"]["families_rms_deg"]}}
    out={
        "protocol_id":cfg["protocol_id"],"sample_interval_utc":[dates[0].isoformat(),dates[-1].isoformat()],
        "days":len(dates),"ephemeris_swe_version":str(swe.version),
        "runtime_versions":{"python":platform.python_version(),"numpy":np.__version__,"scipy":scipy.__version__},
        "ephemeris_flags": {"MOSEPH":True,"J2000":True,"TRUEPOS":True},
        "algorithm":"daily geocentric eight/heliocentric eight/heliocentric nine; 7-body minimum F1 by exhaustive subsets",
        "best_local_minima_daily_note":minima["result_note"],
        "best_local_minima_daily":rank,"snapshot_2029_01_07":safe_snap,
        "frame_invariant_checks":{
            "c7_three_seven_edge_orbits_pass":True,
            "R7_conjunction_vs_heptagon_collision_pass":True,
            "R1_separates_the_two_named_cases_pass":True,
            "max_gap_RMS_change_after_23_44_uniform_shift_deg":max_shifts,
            "max_3D_great_circle_angle_difference_ecliptic_vs_equatorial_deg":max_3d_rot,
            "selection_changes_across_daily_steps":selection_swaps,
        },
        "saturn_conjunctions":dial,
        "inference":"These are exploratory geometric and ephemeris outputs, no p-values or physical coupling; frame changes, selection switches, and period predictions are distinct tests."
    }
    (dest/"results.json").write_text(json.dumps(out,indent=2,default=str),encoding="utf8")
    # Make a very short human-readable machine-generated digest
    lines=["# C7 pilot results", "", f"Run: {dates[0]} through {dates[-1]} inclusive, daily UTC, {len(dates)} samples.",
           "", "All scores are angle-gap RMS degrees, smaller is closer to angular sevenfold spacing.",
           "", "## 2029-01-07 UTC snapshot", "",
           "Snapshot provenance: 2029-01-07 is the test-fixture date from `test_ship.py`, presented first by this template; it carries no significance.", ""]
    if safe_snap:
        for frame,x in safe_snap["lanes"].items():
            lines.append(f"- **{frame}**: F1={x['F1_F2_F3_deg'][0]:.3f}°, F2={x['F1_F2_F3_deg'][1]:.3f}°, F3={x['F1_F2_F3_deg'][2]:.3f}°; "+", ".join(x["angular_order"]))
        lines.append(f"- Same H8-selected seven evaluated geocentrically: F1={safe_snap['same_heliocentric_seven_in_geocentric']['F1_F2_F3_deg'][0]:.3f}°")
    lines.extend(["", "## Sanity checks", "",
                  f"- C7 three edge cycles: PASS (3 × 7 = 21 unique edges)",
                  f"- R7-only conjunction-vs-heptagon alias: PASS; R1 distinguishes those constructed cases.",
                  f"- Maximum F1 shift after subtracting a uniform 23.44°: {max(max_shifts.values()):.3e}°",
                  f"- Maximum physical 3D angular-distance shift after J2000 ecliptic to J2000 equatorial coordinate change: {max_3d_rot:.3e}°",
                  "", "## Saturn event-anchored comparison", ""])
    if dial:
        lines.append("| True conjunction UTC | Days since previous | Error of 365-day dial (days) | 377-day | 378-day |")
        lines.append("|---|---:|---:|---:|---:|")
        for x in dial:
            lines.append(f"| {x['actual_utc']} | {x['since_previous_days'] if x['since_previous_days'] is not None else '—'} | {x['actual_minus_365_days']:.3f} | {x['actual_minus_377_days']:.3f} | {x['actual_minus_378_days']:.3f} |")
    lines.extend(["", "The original Metatronic year starts after spring-equinox sunrise. This comparison instead anchors its provisional dials to an Earth–Saturn orbital alignment. They must not be conflated.",
                  "", "No inferential null or terrestrial-response test was performed."])
    (dest/"RESULTS.md").write_text("\n".join(lines)+"\n",encoding="utf8")
    # reproducibility receipt hashes
    files=["daily_scores.csv","results.json","RESULTS.md"]+(["saturn_dials.csv"] if dial else [])
    checksums={f:hashlib.sha256((dest/f).read_bytes()).hexdigest() for f in files}
    (dest/"checksums.json").write_text(json.dumps(checksums,indent=2),encoding="utf8")
    return out

if __name__=="__main__":
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--config",default="protocol.json")
    ap.add_argument("--out",default="output")
    args=ap.parse_args()
    cfg=json.loads(Path(args.config).read_text(encoding="utf8"))
    result=run(cfg,Path(args.out))
    print(f"PASS: {result['days']} daily samples, {len(result['saturn_conjunctions'])} Earth-Saturn heliocentric conjunctions")
    print("Jan 2029:",result["snapshot_2029_01_07"]["lanes"]["hel9"]["F1_F2_F3_deg"])
    print("Saved output to",Path(args.out).resolve())
