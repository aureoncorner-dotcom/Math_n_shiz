Proposed E-B7 replacements

clock_edge.py, clock_edge13.txt and kimi.txt are proposed drop-in replacements
for loose files named in the errata. All three are byte-identical to
../corrected/clock_edge.py. The original loose files were not uploaded, so this
package does not claim to have edited them or verified their original hashes.
Run ../make_corrected.py to rebuild the corrected script and these replacements.
