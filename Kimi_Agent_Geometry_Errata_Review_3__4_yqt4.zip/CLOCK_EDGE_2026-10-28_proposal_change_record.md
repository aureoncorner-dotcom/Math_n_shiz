# CLOCK-EDGE / RETURN — E-B1–E-B7 proposal change record

**Proposal date:** 2026-10-28  
**Status:** Separate derivative text/code proposal. Uploaded originals and the superseded PDF were not edited.

## Source identity and provenance limitation

- Uploaded verified ZIP SHA-256: `94fa8bfca4ef477d7f133bf6a2ebaa99e16bfbbe4598c6ef574253fb6dce694a`
- Recovered text base: `logs/original_poem.txt`, SHA-256 `66dda61307fd58ced989a6ed7f879421e37ace5419be5875e97b30684aa8a9b0`.
- Preserved original implementation: `original/clock_edge.py`, SHA-256 `6cf163970cfe11809f7cc38fccc8159732bc32f6a0ea6dfc764820fe40181ac5`.
- The errata name `CLOCK-EDGE_RETURN_SILICON_EDITION_final.txt` with hash prefix `7530e4d1…`, but that file was not present in the supplied ZIP or uploads. The recovered poem is later than the superseded PDF and already carries the later Fold/RETURN revisions; it is therefore the working base for this proposal, **without any claim that its hash matches the missing edition of record**.
- Superseded PDF SHA-256: `0f5e72e81205ce0fcf489a66df723dd9bfe1a0e2bc54f39967ce41c8e3a49db6`. It was used only to recover evidence for the conversion bridge and compare wording; it was not edited.
- The two uploaded verification reports are byte-identical, SHA-256 `b87222a7e2374adb8b5a999abd152606d3f4ede25b40619454f78eca52885fe0`; they are not independent corroboration. The packaged report remains labeled as the upstream 2026-10-21 report.

## Applied errata

- **E-B1:** The Residual Note states the strict informative range `n·Ê_ε < 1/78`, threshold behavior, and the n=1 value `ε ≲ 0.2469198819488882321`, with `|ε|` for signed epsilon.
- **E-B2:** The note explicitly extends the Warp panel's `0 < ε < 1` to `0 < |ε| < 1`; bounds and the conversion bridge use signed `1+|ε|` factors.
- **E-B3:** Restored `d_𝕋(θ′, θ) ≤ (1+|ε|)·δ_x` at the end of the Residual Note, with the warped-x error premise.
- **E-B4:** Replaced the Fold wording with `r(θ) ∈ R recovers the current W as its second coordinate`.
- **E-B5:** Restored “temperature is another dial”; marked and footnoted the RETURN n=7 autonomy witness; named `E_ε,sharp` as sharpened without claiming optimality and identified the looser rational certification bound; added the 14-voice poem/audio scope note, including independent summation, no heading oscillators, no phase/weave drive, and no band limiting.
- **E-B6:** README carries the required Decimal boundary and non-boundary defect listing note and designates `audit.py`'s ℚ(√5) arithmetic—not Decimal—as the exact oracle.
- **E-B7:** `loose_script_replacements/` contains proposed `clock_edge.py`, `clock_edge13.txt`, and `kimi.txt` replacements, byte-identical to `corrected/clock_edge.py`. The three original loose files were not uploaded, so no in-place replacement or original-file hash verification was possible.

The standalone proposed TXT and the corrected script's `POEM` string are synchronized. `make_corrected.py` reproduces the numerical corrections and proposed text from the preserved original, and `CORRECTIONS.diff` records the combined diff.

## Validation

- Corrected built-in checks: **70 passed, 0 failed**.
- Independent exact audit: **PASS**, 20,002 exact phase states and 20,001 transitions using rational pairs in ℚ(√5).
- Inverse-defect reproduction and corrected grids: **PASS**; maximum corrected residual in the tested grids is `3.33e-16`.
- Decimal boundary defects and the `Decimal(2)/39` non-boundary counterexample were reproduced. Exact rational arithmetic confirms `39t − 2 = −11×10⁻⁸¹` for the 80-digit Decimal input.
- Standalone-text/POEM synchronization, required E-B text checks, and all three replacement identities: **PASS**.
- Original/corrected voice settings are identical. Full float/PCM reconstruction passed, and the default eight-second WAV is byte-identical to the preserved audio.
- Python 3.8 grammar compatibility passed; execution used CPython 3.12.12 on Linux. Python 3.8 and Windows execution were not available.

## Output identities

| Artifact | SHA-256 |
|---|---|
| `CLOCK-EDGE_RETURN_SILICON_EDITION_final_proposed.txt` | `2cf0e64db8b4bdd7e4a37d80736f5070d15af12c6ce824770f12d242aceefdc5` |
| `corrected/clock_edge.py` | `56c2107a715d1f429452c55585c1a03ccb6fa76fc351eb8966e056fec172e3ab` |
| `original/clock_edge.py` (preserved) | `6cf163970cfe11809f7cc38fccc8159732bc32f6a0ea6dfc764820fe40181ac5` |
| `audio/Signal_Tree_8s.wav` (preserved) | `91dfce1fd0c84698e2e20e88277329671d789fd87cfd898f2118de1853b0f324` |

No physical, biological, AI-hardware, execution, publication, or unresolved-status claim has been promoted. The artwork retains its fixed-width 88-code-point box lines.
