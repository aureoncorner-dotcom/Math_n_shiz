# C7 Planetary Clock Pilot — E-C1–E-C6 proposal change record

**Proposal date:** 2026-10-28  
**Status:** Separate derivative proposal. The uploaded 2026-10-19 package is preserved and remains the base of record for this diff.

## Base identity and preservation

- Uploaded ZIP: `C7_Planetary_Clock_Pilot_2026-10-19.zip`
- ZIP SHA-256: `1ac02c9d121fbe4601b7880821e0579a1156f0539382bf99382a64bf142c679c`
- Base `ship.py` SHA-256: `cf7de696f4feea73faa10961b8f20a84d2d8419971362e4ea197adcaf158a42a`
- Base `protocol.json` SHA-256: `1b6e989d589e5f0c89775a3361165dd0458ab1dc0e1dd245264e2246d4ed7070`
- No uploaded original was edited. The exploratory, descriptive, non-inferential pilot status is unchanged.

## Applied errata

- **E-C1 — Minima selection:** `protocol.json` now declares the daily interior-local-minimum rule, ascending F1 ordering, 30-day minimum separation, five selections per lane, lane order, and non-inferential post-hoc note. `ship.py` reads those parameters. `results.json` places `best_local_minima_daily_note` beside `best_local_minima_daily`.
- **E-C2 — R1 / R7:** README and protocol define R1 as \(|\operatorname{mean} e^{i\theta}|\) and R7 as \(|\operatorname{mean} e^{7i\theta}|\), with range \([0,1]\). The implementation remains unchanged.
- **E-C3 — Snapshot provenance:** The 2029-01-07 fixture-date sentence is in `output/RESULTS.md` and in the `ship.py` template that regenerates it.
- **E-C4 — Dependencies:** `requirements.txt` pins NumPy 2.2.5, SciPy 1.16.2, pyswisseph 2.10.3.2, and matplotlib 3.10.3. The docstring declares SciPy and matplotlib; `brentq` is imported at the top of `run()`. Python, NumPy, and SciPy versions are recorded beside the ephemeris version in `results.json`.
- **E-C5 — Minor cluster:** The scoring formula now explicitly takes the RMS of parenthesized differences and states that F2/F3 residuals are not re-wrapped. H8/G8 are defined. Quick start and the Windows launcher include plotting; `plot_results.py` refreshes six output checksums, including both PNGs. `run_ship.bat` exits immediately if `ship.py` fails and also propagates test/plot failures.
- **E-C6 — Geometry designation:** README now says “working consolidation 2.9, unpublished; designated public reference is 2.8 + publication addendum 1.”

## Regeneration and validation

Validation used CPython 3.12.12, NumPy 2.2.5, SciPy 1.16.2, pyswisseph 2.10.3.2 (Swiss Ephemeris 2.10.03), and matplotlib 3.10.3 on Linux.

- `test_ship.py`: **PASS, 7/7 tests**.
- Full daily run: **PASS, 2,557 samples and 7 Earth–Saturn conjunctions**.
- `daily_scores.csv` is byte-identical to the uploaded baseline: `0b01d06e3d2ca8e81501b98f24ee30161236d61fcc003e468181a44a59f0332e`.
- `saturn_dials.csv` is byte-identical to the uploaded baseline: `63fc19e31a798499fbd4234383cb5d8eb0b33147318661dbffa8faccd9d0f57d`.
- Structural JSON comparison found exactly two added keys (`runtime_versions`, `best_local_minima_daily_note`), no removed keys, and no changed pre-existing values.
- Protocol comparison changed only `scoring` and added only `local_minima_selection`, `R1_R7_definitions`, and `frame_shorthand`; `inference_status` is unchanged.
- Both PNGs were regenerated and visually inspected. All six entries in `output/checksums.json` were independently rehashed and match.
- Windows batch control flow was statically checked; Windows execution was not available.

## Current output identities

| Output | SHA-256 |
|---|---|
| `output/daily_scores.csv` | `0b01d06e3d2ca8e81501b98f24ee30161236d61fcc003e468181a44a59f0332e` |
| `output/results.json` | `70e7012dc28169f7e523b49bf74593e54e1cbaabdceb2e6c27db83b85e2951dc` |
| `output/RESULTS.md` | `d7b4706b4ae12b915eab114f9fb75b8c95a426c92e5f16337d41c35a026a522b` |
| `output/saturn_dials.csv` | `63fc19e31a798499fbd4234383cb5d8eb0b33147318661dbffa8faccd9d0f57d` |
| `output/frame_comparison_2028_2029.png` | `1d0f22aaec8eb3a8ddc462951859d0cce6691d7653b23328116e28a6b01a81c9` |
| `output/saturn_dial_residuals.png` | `4ba31cef341762da1d83d6717071b4edd5ea08e49b55bf03d9b719a28f5c5611` |

No physical coupling, statistical significance, inferential null, terrestrial-response result, production authorization, or new publication status is claimed.
