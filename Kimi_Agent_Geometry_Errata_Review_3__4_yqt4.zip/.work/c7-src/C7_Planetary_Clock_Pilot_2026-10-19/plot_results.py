"""Optional summary figures from CSVs. Uses matplotlib default colors."""
import csv
from datetime import datetime
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
P=Path(__file__).resolve().parent/'output'
data={}
with (P/'daily_scores.csv').open(newline='',encoding='utf8') as f:
 for row in csv.DictReader(f):
  dt=datetime.fromisoformat(row['date_utc'])
  if not datetime(2028,1,1)<=dt<datetime(2030,1,1):continue
  data.setdefault(row['frame'],[]).append((dt,float(row['F1_deg'])))
fig,ax=plt.subplots(figsize=(11,4.6))
for name in ('hel8','geo8','equatorial8','hel9'):
 a=data.get(name,[])
 ax.plot([z[0] for z in a],[z[1] for z in a],label=name,linewidth=1)
ax.set(title='Seven-body spacing error: heliocentric vs geocentric projections (2028–2029)',ylabel='F1 RMS error (degrees)',xlabel='UTC date')
ax.legend(loc='upper right',fontsize=8)
fig.autofmt_xdate();fig.tight_layout();fig.savefig(P/'frame_comparison_2028_2029.png',dpi=150);plt.close(fig)
rows=[]
with (P/'saturn_dials.csv').open(newline='',encoding='utf8') as f:
 rows=list(csv.DictReader(f))
fig,ax=plt.subplots(figsize=(9,4.5))
for p in (365,377,378):
 ax.plot([int(x['n']) for x in rows],[float(x[f'actual_minus_{p}_days']) for x in rows],marker='o',label=f'{p}-day dial')
ax.set(title='Earth–Saturn conjunction timing vs fixed-length prediction dials',xlabel='Conjunction number from the first 2026 event',ylabel='Actual minus predicted time (days)')
ax.legend();fig.tight_layout();fig.savefig(P/'saturn_dial_residuals.png',dpi=150);plt.close(fig)
print('Saved plots.')
