# C7 Planetary Clock Pilot

**Purpose:** Run the selected *Cosmic Time × Geometric Quotient Grammar × heptagon* mathematics on computed planetary positions, and establish which apparent patterns change with coordinate frame, selection rule, or calendar label. **Exploratory, not a planetary influence experiment.**

## Windows quick start (PowerShell)

Extract this folder to e.g. `C:\Users\you\Documents\C7_Pilot`, then open PowerShell in that folder:

```powershell
py -m pip install -r requirements.txt
py ship.py --config protocol.json --out output
```

Run on the provided default parameters to reproduce `output/RESULTS.md`, `output/results.json`, `output/daily_scores.csv`, `output/saturn_dials.csv`. Hashes of outputs are in `output/checksums.json`. Python 3.11+ recommended.

## Frozen *pilot* setup

- Days: January 1, 2026 through December 31, 2032 at 00:00 UTC. Uses Swiss Ephemeris with Moshier analytical solar-system calculations; geometric true-position J2000 ecliptic longitudes.
- Shared labels: Mercury, Venus, Mars, Jupiter, Saturn, Uranus, Neptune, Pluto. Both **heliocentric** and **geocentric** use *those same eight bodies*, with all eight possible 7-of-8 selections.
- A separate exploratory **heliocentric nine-body** lane adds Earth and searches all 36 possible 7-of-9 selections, allowing comparison to previous heptagon work.
- Geocentric Earth is undefined as a planetary direction: it is the observing origin. Geocentric Sun could be included as a different ninth object, but is **not** included in the primary shared-body comparison.
- A geocentric J2000 equatorial right-ascension projection shows what changing the *projected angle coordinates* does. Three-dimensional great-circle separations are tested for invariance under a coordinate rotation.
- Subtract 23.44 degrees from every ecliptic longitude at a given instant as a **reference-shift sanity test only**. This is **not** sidereal zodiac conversion; sidereal ayanamsa must be chosen by system and epoch. A uniform zodiac-zero change leaves all relative angular-gap scores unchanged.
- For every seven-body subset, sort longitudes and calculate RMS angular errors in the three C7 edge families (steps 1, 2, and 3). Rank by adjacent-gap RMS F1. Track R1 and R7, label ordering, and best subset switches.
- Earth–Saturn heliocentric conjunction means \(\lambda_\oplus - \lambda_S = 0\bmod360^\circ\). Compute those dates and compare three *event-anchored* constant-period predictors (365, 377, 378 days). They **are not** the equinox-sunrise calendar! Full traditional Metatronic intercalation requires a declared site/time zone and sunrise conventions.

## Sources and mathematical boundaries

- [Modular Planetary Recurrence Geometry](https://github.com/aureoncorner-dotcom/Toroidal_scrotal_posturing/blob/main/Modular%20Planetary%20Recurrence%20Geometry.txt): defines geocentric longitude state \(\Lambda(t)\) and its quotient by common rotation. We label all frames so a heliocentric comparison is not silently imported from that source.
- [Geometry Master 2.9](https://github.com/aureoncorner-dotcom/Toroidal_scrotal_posturing/blob/main/geomas_2.9.md): witness-relative information loss, prediction and status restrictions.
- [Math_n_shiz Triadic Overlap v2.1](https://github.com/aureoncorner-dotcom/Math_n_shiz/blob/main/triadic_overlapV2.1.md): distinguishes retained state, relational context \(\mathcal L\), and different return witnesses.
- [Clock as a Bifurcation Machine v0.4](https://github.com/aureoncorner-dotcom/Toroidal_scrotal_posturing/blob/main/The%20Clock%20Is%20a%20Bifurcation%20Machine%20%E2%80%94%20Geometry-Corrected%20v0.4%20Residual%20Descent%20(4).txt): a geometric crossing or classification change alone does *not* establish a dynamical bifurcation.

## What constitutes PASS

1. Three seven-edge C7 orbits exhaust the 21 K7 edges.
2. Uniform 23.44-degree coordinate shift preserves gap RMS.
3. The equal-R7 ambiguity (seven conjunct vs regular sevenfold polygon) is exhibited; R1 distinguishes those two cases but is not claimed globally sufficient.
4. 3-D spherical separations are unchanged by ecliptic-to-equatorial conversion to numerical tolerance, while projected angle gap scores may change.
5. A daily, frame-separated CSV and Saturn event-time table are written with no reference to historical events, personal information, or terrestrial measurements.

## What remains UNTESTED

- Any celestial force or coupling inferred from chord scores.
- Whether heptagon episodes exceed an exposure-matched astronomical surrogate null (full 7-of-N search, temporal autocorrelation, and date scanning must be included in that null).
- Whether these angles predict Earth solar-wind/Kp/Schumann observations beyond known external drivers and multiple testing.
- The Metatronic calendar's operational equinox/first-sunrise intercalation and its observatory location.
- A genuine clock bifurcation under a declared dynamical equation and control parameter.

The current run is a **calibration / model-debugging baseline**; it cannot establish causation or a personal astronomical role.
