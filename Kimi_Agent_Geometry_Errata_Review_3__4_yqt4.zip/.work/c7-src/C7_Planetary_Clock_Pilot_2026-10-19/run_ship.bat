@echo off
cd /d "%~dp0"
py ship.py --config protocol.json --out output
if errorlevel 1 echo RUN FAILED: ensure you have Python and the dependencies in requirements.txt
py test_ship.py
pause
