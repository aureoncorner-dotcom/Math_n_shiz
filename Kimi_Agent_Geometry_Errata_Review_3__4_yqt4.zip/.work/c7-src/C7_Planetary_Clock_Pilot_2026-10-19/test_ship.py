"""Fast independent consistency tests for the C7 pilot (no ephemeris scan needed)."""
import itertools
import json
import math
from pathlib import Path
import swisseph as swe
from ship import IDEAL, coords, best7, score, great_circle_deg

HERE = Path(__file__).resolve().parent
CFG = json.loads((HERE / "protocol.json").read_text(encoding="utf-8"))
assert len(CFG["bodies_common"]) == 8
assert "Earth" not in CFG["bodies_common"]
assert "Earth" in CFG["bodies_heliocentric_plus_earth"]
assert len(list(itertools.combinations(CFG["bodies_common"], 7))) == 8
assert len(list(itertools.combinations(CFG["bodies_heliocentric_plus_earth"], 7))) == 36

# The three C7 edge orbits must be disjoint and cover every unordered edge once.
edges = {frozenset((i,j)) for i,j in itertools.combinations(range(7),2)}
families = [{frozenset((i,(i+k)%7)) for i in range(7)} for k in (1,2,3)]
assert sum(len(x) for x in families)==21
assert not(families[0]&families[1] or families[0]&families[2] or families[1]&families[2])
assert set.union(*families)==edges

# Uniform common angular offsets cannot affect any of the three gap RMS scores.
sample = {'A':1., 'B':45., 'C':111.,'D':160.,'E':201.,'F':250.,'G':323.}
p1 = score(list(sample),sample)
for shift in (-23.44,0,23.44,147.5):
    p2=score(list(sample),{k:(v+shift)%360 for k,v in sample.items()})
    for a,b in zip(p1['families_rms_deg'],p2['families_rms_deg']):assert abs(a-b)<1e-12

# The Fourier R7-magnitude exactly aliases co-alignment and a regular sevenfold figure.
reg={str(i):i*IDEAL for i in range(7)}
col={str(i):97. for i in range(7)}
r,c=score(list(reg),reg),score(list(col),col)
assert abs(r['R7']-c['R7'])<1e-12
assert r['R1']<1e-12 and abs(c['R1']-1)<1e-12

# A real change of coordinate plane changes 2D projected angles, not 3D angular distances.
jd = swe.julday(2029,1,7,0)
bodies=CFG['bodies_common']
geoc, equ = coords(jd,bodies,'geo'),coords(jd,bodies,'eq')
for a,b in itertools.combinations(bodies,2):
    assert abs(great_circle_deg(geoc,a,b)-great_circle_deg(equ,a,b))<1e-7

# A hand-off from H8 to G8 retains the same seven identity labels: no mixing membership.
helioc = coords(jd,bodies,'hel')
h = best7(bodies,{k:v[0] for k,v in helioc.items()})
g = score(h['members'],{k:v[0] for k,v in geoc.items()})
assert h['members']==g['members']

# Fixed year arithmetic; the hinges are outside the original 52 named musical weeks.
assert 13*28+1==365 and 13*(28+1)+1==378 and 364//7==52

print('PASS: 7 tests: body sets, edge orbits, common rotation, R7 collision, 3D frame, matched members, calendar arithmetic')
