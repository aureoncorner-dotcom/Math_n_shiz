# C7 pilot results

Run: 2026-01-01 through 2032-12-31 inclusive, daily UTC, 2557 samples.

All scores are angle-gap RMS degrees, smaller is closer to angular sevenfold spacing.

## 2029-01-07 UTC snapshot

- **hel8**: F1=15.924°, F2=19.774°, F3=15.388°; Neptune, Saturn, Uranus, Mars, Jupiter, Venus, Pluto
- **geo8**: F1=29.900°, F2=28.325°, F3=28.683°; Neptune, Saturn, Uranus, Mars, Jupiter, Venus, Pluto
- **equatorial8**: F1=30.816°, F2=29.758°, F3=29.673°; Neptune, Saturn, Uranus, Mars, Jupiter, Venus, Pluto
- **hel9**: F1=7.367°, F2=12.404°, F3=14.909°; Neptune, Mercury, Earth, Mars, Jupiter, Venus, Pluto
- Same H8-selected seven evaluated geocentrically: F1=29.900°

## Sanity checks

- C7 three edge cycles: PASS (3 × 7 = 21 unique edges)
- R7-only conjunction-vs-heptagon alias: PASS; R1 distinguishes those constructed cases.
- Maximum F1 shift after subtracting a uniform 23.44°: 1.776e-14°
- Maximum physical 3D angular-distance shift after J2000 ecliptic to J2000 equatorial coordinate change: 1.464e-11°

## Saturn event-anchored comparison

| True conjunction UTC | Days since previous | Error of 365-day dial (days) | 377-day | 378-day |
|---|---:|---:|---:|---:|
| 2026-10-04T12:16:06Z | — | 0.000 | 0.000 | 0.000 |
| 2027-10-18T00:22:32Z | 378.50447162007913 | 13.504 | 1.504 | 0.504 |
| 2028-10-30T17:20:33Z | 378.7069547511637 | 27.211 | 3.211 | 1.211 |
| 2029-11-13T14:47:31Z | 378.893725738395 | 41.105 | 5.105 | 2.105 |
| 2030-11-27T15:42:41Z | 379.03831193223596 | 55.143 | 7.143 | 3.143 |
| 2031-12-11T18:47:09Z | 379.12810381827876 | 69.272 | 9.272 | 4.272 |
| 2032-12-24T22:42:47Z | 379.16363556310534 | 83.435 | 11.435 | 5.435 |

The original Metatronic year starts after spring-equinox sunrise. This comparison instead anchors its provisional dials to an Earth–Saturn orbital alignment. They must not be conflated.

No inferential null or terrestrial-response test was performed.
