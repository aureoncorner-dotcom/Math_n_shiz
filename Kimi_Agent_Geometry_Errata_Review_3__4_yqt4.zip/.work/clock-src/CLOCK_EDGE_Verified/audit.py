"""Reproduce the independent CLOCK-EDGE audit (standard library, Python 3.8+).

Run from any directory: python audit.py
The recovered original and the separate corrected source are never edited.
"""
import ast
import contextlib
import hashlib
import importlib.util
import io
import json
import math
from decimal import Decimal
from fractions import Fraction as Q
from pathlib import Path
import struct
import subprocess
import sys
import tempfile
import wave

ROOT = Path(__file__).resolve().parent


def load(name):
    spec = importlib.util.spec_from_file_location(name, ROOT / name / 'clock_edge.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class Quadratic:
    """Exact a + b*sqrt(5), with rational a,b and exact order comparisons."""
    def __init__(self, a=0, b=0):
        self.a, self.b = Q(a), Q(b)

    def __add__(self, other):
        if not isinstance(other, Quadratic):
            other = Quadratic(other)
        return Quadratic(self.a + other.a, self.b + other.b)

    __radd__ = __add__

    def __neg__(self):
        return Quadratic(-self.a, -self.b)

    def __sub__(self, other):
        return self + (-other if isinstance(other, Quadratic) else -Q(other))

    def __mul__(self, other):
        return Quadratic(self.a * other, self.b * other)

    __rmul__ = __mul__

    def __truediv__(self, other):
        return self * (Q(1) / other)

    def sign(self):
        a, b = self.a, self.b
        sign = lambda x: (x > 0) - (x < 0)
        if b == 0:
            return sign(a)
        if a == 0 or sign(a) == sign(b):
            return sign(b)
        return sign(a) * sign(a * a - 5 * b * b)

    def __lt__(self, other):
        return (self - other).sign() < 0

    def __gt__(self, other):
        return (self - other).sign() > 0

    def __eq__(self, other):
        return (self - other).sign() == 0

    def floor(self):
        # Float supplies only a starting guess. Exact comparisons certify the result.
        k = math.floor(float(self.a) + float(self.b) * math.sqrt(5))
        while self < k:
            k -= 1
        while not self < k + 1:
            k += 1
        return k

    def frac(self):
        return self - self.floor()


def exact_phase_audit(module):
    alpha = Quadratic(Q(3, 2), Q(-1, 2))
    tau = Quadratic(15) - 39 * alpha
    assert 0 < tau < Q(1, 2)
    assert 9 * tau < 1 < 10 * tau
    phases = [(n * alpha).frac() for n in range(20002)]
    bins = [(39 * t).floor() for t in phases]
    rhos = [39 * t - b for t, b in zip(phases, bins)]
    strands = [b % 3 for b in bins]
    slips = [int(r < tau) for r in rhos]
    errors_bound = Q(1, 10 ** 60)
    for n, t in enumerate(phases):
        approx = module.theta(n)
        error = t - Q(approx)
        assert -errors_bound < error < errors_bound
        assert (module.b_of(approx), module.s_of(approx), module.sigma_of(approx)) == (bins[n], strands[n], slips[n])
        z = (13 * t).frac()
        assert z == (strands[n] + rhos[n]) / 3
        if n + 1 < len(phases):
            assert (t + alpha).frac() == phases[n + 1]
            assert (bins[n + 1] - bins[n]) % 39 == 15 - slips[n]
            assert rhos[n + 1] == rhos[n] - tau + slips[n]
            assert strands[n + 1] == (strands[n] - slips[n]) % 3
            assert (z - tau / 3).frac() == (13 * phases[n + 1]).frac()
    sigma = lambda t: int((39 * t).frac() < tau)
    pi = lambda t: ((39 * t).floor() % 3, sigma(t))
    F = lambda t: (t + alpha).frac()
    r = lambda t: (*pi(t), sigma(F(t)))
    assert r(phases[1]) == r(phases[7]) == (2, 0, 0)
    assert r(F(phases[1])) == (2, 0, 0)
    assert r(F(phases[7])) == (2, 0, 1)
    for b in range(39):
        assert sigma(Quadratic(b) / 39) == 1
        assert sigma((b + tau) / 39) == 0
        # Witnesses of both next slips in every current (s,0) fiber.
        assert sigma(F((b + tau) / 39)) == 1
        assert sigma(F((b + 2 * tau) / 39)) == 0
    positions = [n for n, slip in enumerate(slips[:20000]) if slip]
    gaps = sorted({b - a for a, b in zip(positions, positions[1:])})
    assert gaps == [9, 10]
    group = {(a, b) for a in range(6) for b in range(4)}
    diagonal = {(k % 6, k % 4) for k in range(12)}
    assert diagonal == {p for p in group if (p[0] - p[1]) % 2 == 0}
    assert len(group) == 24 and len(diagonal) == 12
    assert len({15 * k % 39 for k in range(39)}) == 13
    return {'exact_phase_states': len(phases), 'transition_checks': len(phases) - 1,
            'arithmetic': 'rational pairs a+b*sqrt(5), exact comparison',
            'decimal_phase_error_bound': 'strictly less than 1e-60 for tested states',
            'exact_boundary_bins': 39, 'slip_positions_in_first_20000': len(positions),
            'complete_slip_gaps': gaps, 'finite_group_states': 24,
            'counter_witnesses': 'PASS'}


def inverse_audit(original, corrected):
    results = {}
    for eps in (.9, .99, .999, -.99):
        row = {}
        for label, module in [('original', original), ('corrected', corrected)]:
            errors = [abs(module.h(eps, module.h_inv(eps, k / 2000)) - k / 2000) for k in range(2001)]
            i = max(range(len(errors)), key=errors.__getitem__)
            row[label] = {'max_lift_residual': errors[i], 'worst_u': i / 2000,
                          'count_above_1e-12': sum(e > 1e-12 for e in errors)}
            if label == 'corrected':
                assert max(errors) < 1e-12
        results[str(eps)] = row
    return results


def cli_audit(original, corrected):
    results = {}
    with tempfile.TemporaryDirectory() as td:
        wav = str(Path(td) / 'sample.wav')
        cases = {'verify': ['--verify'], 'help': ['--help'], 'poem': [],
                 'run20': ['--run', '20'], 'run0': ['--run', '0'],
                 'combined': ['--verify', '--run', '2', '--wav', wav, '--seconds', '.04'],
                 'short': ['--wav', wav, '--seconds', '.01'],
                 'zero': ['--wav', wav, '--seconds', '0'],
                 'negative_duration': ['--wav', wav, '--seconds', '-1'],
                 'too_short': ['--wav', wav, '--seconds', '.000001'],
                 'nan': ['--wav', wav, '--seconds', 'nan'],
                 'infinite': ['--wav', wav, '--seconds', 'inf'],
                 'huge': ['--wav', wav, '--seconds', '1e300'],
                 'negative_run': ['--run', '-1'], 'unknown': ['--wat'],
                 'bad_type': ['--run', 'abc'],
                 'unwritable': ['--wav', str(Path(td) / 'absent' / 'sample.wav')]}
        bad = {'zero', 'negative_duration', 'too_short', 'nan', 'infinite', 'huge',
               'negative_run', 'unknown', 'bad_type', 'unwritable'}
        for name, args in cases.items():
            r = subprocess.run([sys.executable, str(ROOT/'corrected/clock_edge.py')] + args,
                               capture_output=True, text=True, timeout=60)
            expected = 2 if name in bad else 0
            assert r.returncode == expected, (name, r.returncode, r.stderr)
            assert 'Traceback' not in r.stderr, (name, r.stderr)
            results[name] = {'exit': r.returncode, 'expected_exit': expected}
            if name in {'verify', 'run20', 'combined'}:
                (ROOT/'logs'/('corrected_' + name + '.txt')).write_text(r.stdout + r.stderr, encoding='utf-8')
        # Re-render both implementations. The corrected sample must be byte-identical.
        with contextlib.redirect_stdout(io.StringIO()):
            original.render(wav, 8)
            original_bytes = Path(wav).read_bytes()
            corrected.render(wav, 8)
        assert Path(wav).read_bytes() == original_bytes == (ROOT/'audio/Signal_Tree_8s.wav').read_bytes()
        for seconds in (.01, .02, .03, .04, 1/44100):
            with contextlib.redirect_stdout(io.StringIO()):
                corrected.render(wav, seconds)
            with wave.open(wav, 'rb') as w:
                assert w.getnframes() == int(seconds*44100)
        # Non-default sample rate via the public function, not a nonexistent CLI option.
        with contextlib.redirect_stdout(io.StringIO()):
            corrected.render(wav, .04, 48000)
        with wave.open(wav, 'rb') as w:
            assert w.getframerate() == 48000 and w.getnframes() == 1920
        for rate in (0, -1, 44100.5, True, 2147483648):
            try:
                corrected.render(wav, .01, rate)
            except ValueError:
                pass
            else:
                raise AssertionError('invalid rate accepted')
    assert original.POEM == corrected.POEM and original.VOICES == corrected.VOICES
    results['composition_preservation'] = {'poem_identical': True, 'voices_identical': True,
        'default_wav_byte_identical': True, 'short_and_48000_hz_wav_headers': 'PASS'}
    return results


def pcm_audit(module):
    rate, n = 44100, 352800
    buf = [0.0] * n
    for f, kind, level in module.VOICES:
        inc = f / rate
        for i in range(n):
            buf[i] += level * module.osc(kind, i*inc)
    fade = int(.02*rate)
    for i in range(fade):
        buf[i] *= i / fade
        buf[-1-i] *= i / fade
    assert all(math.isfinite(x) for x in buf)
    peak = max(map(abs, buf))
    expected = b''.join(struct.pack('<h', int(32767*.9*x/peak)) for x in buf)
    with wave.open(str(ROOT/'audio/Signal_Tree_8s.wav'), 'rb') as w:
        assert w.getparams()[:4] == (1, 2, rate, n)
        actual = w.readframes(n)
        assert actual == expected
    return {'float_samples': n, 'nonfinite_float_samples': 0, 'pre_normalization_peak': peak,
            'pcm_matches_recomputed_mix': True, 'saturation_or_clamping_used': False}


def main():
    original, corrected = load('original'), load('corrected')
    result = {'runtime': sys.version, 'platform': sys.platform}
    for name in ('original', 'corrected'):
        path = ROOT/name/'clock_edge.py'
        tree = ast.parse(path.read_text(encoding='utf-8-sig'), feature_version=(3, 8))
        compile(tree, str(path), 'exec')
        result[name + '_sha256'] = hashlib.sha256(path.read_bytes()).hexdigest()
    print('Syntax and Python 3.8 grammar: PASS', flush=True)
    result['exact_math'] = exact_phase_audit(original)
    print('Exact independent algebra and phase comparisons: PASS', flush=True)
    result['inverse_grid'] = inverse_audit(original, corrected)
    print('Inverse bug reproduced; correction passes boundary grids', flush=True)
    boundaries = []
    for b in range(39):
        t = Decimal(b) / 39
        if original.b_of(t) != b or original.sigma_of(t) != 1:
            boundaries.append({'intended_exact_bin': b, 'decimal_bin': original.b_of(t),
                'decimal_slip': original.sigma_of(t), '39theta_minus_b': str(39*t-b)})
    result['decimal_boundary_rounding'] = boundaries
    result['cli'] = cli_audit(original, corrected)
    result['pcm'] = pcm_audit(original)
    (ROOT/'logs/independent_audit.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
    print('CLI, composition preservation, PCM: PASS', flush=True)
    print(json.dumps(result['exact_math'], indent=2))


if __name__ == '__main__':
    main()
