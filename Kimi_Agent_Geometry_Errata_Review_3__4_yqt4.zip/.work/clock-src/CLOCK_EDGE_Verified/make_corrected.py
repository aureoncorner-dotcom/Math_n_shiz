"""Create a separately labeled correction; never edit the recovered original."""
from pathlib import Path
import difflib

root = Path(__file__).resolve().parent
original = (root / 'original/clock_edge.py').read_text(encoding='utf-8-sig')
source = original
source = source.replace('recompute and check every mathematical claim',
                        'run the built-in finite and numerical checks')
source = source.replace('Everything below recomputes what the poem states.',
                        'Finite checks and numerical evidence for the stated model.')
start = source.index('def h_inv(eps, u):')
end = source.index('\n\n\n\ndef G(', start)
source = source[:start] + '''def h_inv(eps, u):
    """Bracketed numerical inverse for finite u and |eps| < 1.

    h is strictly increasing and |h(x)-x| < 1/(2*pi), so the
    root lies inside [u-0.5, u+0.5]. Bisection avoids unguarded
    Newton divergence near |eps| = 1. This is floating-point,
    not an exact symbolic inverse.
    """
    if not math.isfinite(eps) or abs(eps) >= 1 or not math.isfinite(u):
        raise ValueError("h_inv requires finite u and finite |eps| < 1")
    if eps == 0:
        return u
    lo, hi = u - 0.5, u + 0.5
    for _ in range(64):
        mid = lo + (hi - lo) / 2
        if mid == lo or mid == hi:
            return mid
        if h(eps, mid) < u:
            lo = mid
        else:
            hi = mid
    return lo + (hi - lo) / 2
''' + source[end:]
source = source.replace('not all(x >= y for x, y in zip(d_seq, d_seq[1:])))',
'''not all(x >= y for x, y in zip(d_seq, d_seq[1:]))
            and not all(x <= y for x, y in zip(d_seq, d_seq[1:])))''')
source = source.replace('F_ε = h_ε⁻¹∘F∘h_ε is an exact conjugate (ε={eps})',
                        'numerical inverse residual for conjugate F_ε (ε={eps})')
source = source.replace('''    n = int(seconds * rate)
    buf = [0.0] * n''', '''    if not isinstance(rate, int) or isinstance(rate, bool) or not 1 <= rate <= 2147483647:
        raise ValueError("rate must be a positive integer fitting PCM WAV fields")
    if not math.isfinite(seconds) or seconds <= 0:
        raise ValueError("seconds must be positive and finite")
    frame_count = seconds * rate
    if not math.isfinite(frame_count) or not 1 <= frame_count <= (4294967295 - 36) // 2:
        raise ValueError("duration must fit at least one sample and a standard RIFF WAV")
    n = int(frame_count)
    buf = [0.0] * n''')
source = source.replace('fade = int(0.02 * rate)', 'fade = min(int(0.02 * rate), n // 2)')
source = source.replace('with wave.open(path, "wb") as w:',
                        'with open(path, "wb") as output, wave.open(output, "wb") as w:')
source = source.replace('help="recompute and check every claim in the poem"',
                        'help="run the built-in finite and numerical checks"')
source = source.replace('''    args = ap.parse_args()
''', '''    args = ap.parse_args()
    if args.run is not None and args.run < 0:
        ap.error("--run must be nonnegative")
    if not math.isfinite(args.seconds) or args.seconds <= 0:
        ap.error("--seconds must be positive and finite")
    if args.wav and not 1 <= args.seconds * 44100 <= (4294967295 - 36) // 2:
        ap.error("--seconds must fit at least one sample and a standard RIFF WAV")
''')
source = source.replace('''        render(args.wav, args.seconds)''', '''        try:
            render(args.wav, args.seconds)
        except (OSError, ValueError) as exc:
            ap.error(str(exc))''')
(root / 'corrected/clock_edge.py').write_bytes(source.encode('utf-8'))
diff = ''.join(difflib.unified_diff(original.splitlines(True), source.splitlines(True),
                                  fromfile='original/clock_edge.py', tofile='corrected/clock_edge.py'))
(root / 'CORRECTIONS.diff').write_text(diff, encoding='utf-8')
print('Created corrected copy and normalized unified diff; original bytes untouched.')
